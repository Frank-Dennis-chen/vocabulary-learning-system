# 背單字系統英打

A Pen created on CodePen.

Original URL: [https://codepen.io/frank-chen-the-bold/pen/XJbYYyV](https://codepen.io/frank-chen-the-bold/pen/XJbYYyV).

